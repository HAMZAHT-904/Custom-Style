import os, sys, tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["LAB_CKPT_DIR"] = tempfile.mkdtemp(prefix="lab_ckpt_")   # tests never touch real checkpoints
