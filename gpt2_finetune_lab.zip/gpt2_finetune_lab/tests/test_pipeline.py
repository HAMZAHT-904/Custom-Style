"""Tests use the offline tiny model (random 2-layer GPT-2) so they run in seconds without downloads.
They verify the pipeline; they do not measure real GPT-2 quality."""
import math
import time
from pathlib import Path

import pytest
import torch
from fastapi.testclient import TestClient

from backend import core
from backend.app import app

DATA = Path(__file__).resolve().parent.parent / "data" / "campus_announcements.txt"
TEXTS = core.split_examples(core.clean_text(DATA.read_text()))


@pytest.fixture(scope="module")
def trained():
    prog = core.Progress()
    cfg = core.TrainConfig(base_model=core.TINY, run_name="t_run", epochs=12, batch_size=8, lr=3e-3, block_size=32)
    meta = core.train(TEXTS, cfg, prog)
    return prog, meta


# ---- training data preparation
def test_clean_text_normalises():
    raw = "Hello\r\n\r\n\r\n\r\nWorld \t  with   spaces\x00 \n"
    out = core.clean_text(raw)
    assert "\r" not in out and "\x00" not in out and "\n\n\n" not in out and "  " not in out


def test_split_examples_by_blank_line_and_by_line():
    assert core.split_examples("First example here.\nstill first.\n\nSecond example here.") == \
        ["First example here. still first.", "Second example here."]
    assert len(core.split_examples("line number one\nline number two\nline number three")) == 3
    assert core.split_examples("short\n\n\n   \n") == []


def test_tokenizer_blocks_and_split(tmp_path):
    tok = core.build_tiny_tokenizer(TEXTS, tmp_path / "tok")
    text = TEXTS[0]
    assert tok.decode(tok.encode(text)) == text                       # lossless round trip
    train, val, bs, info = core.prepare_data(TEXTS, tok, 32)
    assert train.shape[1] == val.shape[1] == bs and len(train) > 0 and len(val) > 0
    assert info["tokens"] > 500


def test_too_small_dataset_rejected(tmp_path):
    tok = core.build_tiny_tokenizer(TEXTS, tmp_path / "tok")
    with pytest.raises(ValueError):
        core.prepare_data(["hi there"], tok, 32)


# ---- fine-tuning + loss monitoring
def test_training_loss_decreases(trained):
    prog, meta = trained
    losses = [p["loss"] for p in prog.train_log]
    k = max(5, len(losses) // 10)
    assert sum(losses[-k:]) / k < sum(losses[:k]) / k - 0.5          # clear drop
    assert all(math.isfinite(x) for x in losses)


def test_validation_loss_improves_and_is_logged_each_epoch(trained):
    prog, meta = trained
    assert len(prog.val_log) == 12 + 1                                # step 0 + one per epoch
    assert prog.val_log[-1]["val_loss"] < prog.val_log[0]["val_loss"]
    assert meta["final_val_loss"] < meta["initial_val_loss"]
    assert prog.status == "done" and prog.step == prog.total_steps


def test_checkpoint_roundtrip(trained):
    base, ft, tok, meta = core.load_run("t_run")
    again = core.GPT2LMHeadModel.from_pretrained(core.ckpt_root() / "t_run" / "model").eval()
    x = tok("Attention students: the library", return_tensors="pt").input_ids
    with torch.no_grad():
        assert torch.allclose(ft(x.to(next(ft.parameters()).device)).logits.cpu(), again(x).logits, atol=1e-5)
    assert (core.ckpt_root() / "t_run" / "meta.json").exists()


def test_stop_saves_checkpoint():
    prog = core.Progress(stop=True)
    meta = core.train(TEXTS, core.TrainConfig(core.TINY, "t_stop", epochs=3, batch_size=8, block_size=32), prog)
    assert prog.status == "stopped" and (core.ckpt_root() / "t_stop" / "model" / "config.json").exists()


# ---- generation + how the custom data influences it
def test_generation_is_seeded_and_keeps_prompt(trained):
    base, ft, tok, meta = core.load_run("t_run")
    a = core.generate(ft, tok, "Attention students:", max_new_tokens=20, seed=3)
    b = core.generate(ft, tok, "Attention students:", max_new_tokens=20, seed=3)
    assert a == b and a.startswith("Attention students:")


def test_finetuned_model_reflects_custom_data(trained):
    res = core.compare("t_run", "Attention students:", n=5, max_new_tokens=40, seed=0)
    ft_m, base_m = res["finetuned_metrics"], res["base_metrics"]
    assert ft_m["coverage"] > base_m["coverage"]                      # more words from the dataset
    assert ft_m["keyword_hits"] > base_m["keyword_hits"]
    assert res["val_loss"]["after"] < res["val_loss"]["before"]


def test_domain_influence_metric():
    vocab, kw = {"library", "students"}, ["library"]
    assert core.domain_influence("the library students", vocab, kw) == {"coverage": 1.0, "keyword_hits": 1}
    assert core.domain_influence("zebra giraffe", vocab, kw)["coverage"] == 0.0


# ---- API
def test_api_end_to_end():
    c = TestClient(app)
    assert c.post("/api/train", json={"run_name": "x"}).status_code == 400       # no dataset yet
    r = c.post("/api/dataset/sample"); assert r.status_code == 200 and r.json()["examples"] == len(TEXTS)
    r = c.post("/api/dataset/file", files={"file": ("d.txt", DATA.read_bytes(), "text/plain")})
    assert r.status_code == 200
    assert c.post("/api/dataset/text", json={"text": "  \n "}).status_code == 400
    bad = c.post("/api/train", json={"run_name": "../evil"}); assert bad.status_code == 422
    r = c.post("/api/train", json={"base_model": core.TINY, "run_name": "api_run", "epochs": 8, "batch_size": 8,
                                   "lr": 3e-3, "block_size": 32})
    assert r.status_code == 200
    for _ in range(120):
        s = c.get("/api/status").json()
        if s["status"] in ("done", "error"):
            break
        time.sleep(0.5)
    assert s["status"] == "done", s["message"]
    assert len(s["train_log"]) == s["total_steps"] and "api_run" in [x["run_name"] for x in c.get("/api/runs").json()]
    g = c.post("/api/generate", json={"run": "api_run", "prompt": "Attention students:", "max_new_tokens": 15, "samples": 2})
    assert g.status_code == 200 and len(g.json()["base"]) == 2 and len(g.json()["finetuned"]) == 2
    assert c.post("/api/generate", json={"run": "missing", "prompt": "x"}).status_code == 404
    assert c.get("/").status_code == 200
