"""Starter script: fine-tune from the command line and print before/after generations.
   python cli.py --data data/campus_announcements.txt --base distilgpt2 --epochs 3 --prompt "Attention students:"
   python cli.py --base tiny-offline --epochs 30      # no download, for a quick pipeline check
"""
import argparse
from pathlib import Path

from backend import core

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="data/campus_announcements.txt")
ap.add_argument("--base", default="distilgpt2", help="distilgpt2 | gpt2 | tiny-offline")
ap.add_argument("--run", default="cli_run")
ap.add_argument("--epochs", type=int, default=3)
ap.add_argument("--batch", type=int, default=4)
ap.add_argument("--lr", type=float, default=5e-5)
ap.add_argument("--block", type=int, default=64)
ap.add_argument("--prompt", default="Attention students:")
a = ap.parse_args()

texts = core.split_examples(core.clean_text(Path(a.data).read_text()))
print(f"{len(texts)} training examples")
prog = core.Progress()
meta = core.train(texts, core.TrainConfig(a.base, a.run, a.epochs, a.batch, a.lr, a.block), prog)
print(f"val loss {meta['initial_val_loss']:.3f} -> {meta['final_val_loss']:.3f} in {meta['seconds']}s")
res = core.compare(a.run, a.prompt, n=2, seed=1)
for i, (b, f) in enumerate(zip(res["base"], res["finetuned"]), 1):
    print(f"\n--- sample {i} ---\nBASE      : {b}\nFINE-TUNED: {f}")
print("\ndomain metrics:", res["base_metrics"], "vs", res["finetuned_metrics"])
